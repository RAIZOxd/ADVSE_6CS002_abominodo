package com.wlv.abominodo.serconnection;
import com.wlv.abominodo.views.IOLibrary;

public class IOSpecialist {
  public IOSpecialist() {   
  }
  public String getString(){
    return IOLibrary.getString();
  }
}
